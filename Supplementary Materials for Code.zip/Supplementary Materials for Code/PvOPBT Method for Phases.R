
Data_antibiotic_Num_Sample_R0.95<-matrix(nrow = 110,ncol =20)
Data_antibiotic_Num_Sample_Pv1_1<-matrix(nrow = 110,ncol =27)
Data_antibiotic_Num_Sample_Pv2_1<-matrix(nrow = 110,ncol =27)
Data_antibiotic_Num_Sample_O1_A<-matrix(nrow = 110,ncol =27)
Data_antibiotic_Num_Sample_O1_S<-matrix(nrow = 110,ncol =27)
Data_antibiotic_Num_Sample_O2_A<-matrix(nrow = 110,ncol =27)
Data_antibiotic_Num_Sample_O2_S<-matrix(nrow = 110,ncol =27)
Data_antibiotic_Num_Sample_Pv1_A_1<-matrix(nrow = 110,ncol =27)
Data_antibiotic_Num_Sample_Pv1_S_1<-matrix(nrow = 110,ncol =27)
Data_antibiotic_Num_Sample_Pv2_S_1<-matrix(nrow = 110,ncol =27)
Data_antibiotic_Num_Sample_Pv2_A_1<-matrix(nrow = 110,ncol =27)

for(j in 1:27)
{
  Data_Sample<- Data_antibiotic_Num2[sample(nrow(Data_antibiotic_Num2),14776),]
  Data_antibiotic_Num_Sample_Pv1<-matrix(nrow = 110,ncol =8 )
  Data_antibiotic_Num_Sample_Pv2<-matrix(nrow = 110,ncol =7 )
  
  Data_antibiotic_Num_Sample_O1<-matrix(nrow = 110,ncol =2 )
  Data_antibiotic_Num_Sample_O2<-matrix(nrow = 110,ncol =2 )
  
  Data_antibiotic_Num_Sample_Pv1_A<-matrix(nrow = 110,ncol =4)
  Data_antibiotic_Num_Sample_Pv1_S<-matrix(nrow = 110,ncol =4)
  
  Data_antibiotic_Num_Sample_Pv2_A<-matrix(nrow = 110,ncol =7)
  Data_antibiotic_Num_Sample_Pv2_S<-matrix(nrow = 110,ncol =7)
  for(a in 1:110)
  {
    for(m in 1:8)
    {
      {media<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Environmental_media==m)
      if(nrow(media)>0)
        
        Data_antibiotic_Num_Sample_Pv1[a,m]<-1
      else
        Data_antibiotic_Num_Sample_Pv1[a,m]<-0}
      
      if(m<5)
      {
        media_A<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Environmental_media==m)
        if(nrow(media_A)>0)
          
          Data_antibiotic_Num_Sample_Pv1_A[a,m]<-1
        
        else
          Data_antibiotic_Num_Sample_Pv1_A[a,m]<-0
        
      }
      else
      {
        media_S<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Environmental_media==m)
        if(nrow(media_S)>0)
          
          Data_antibiotic_Num_Sample_Pv1_S[a,m-4]<-1
        else
          Data_antibiotic_Num_Sample_Pv1_S[a,m-4]<-0}
      
    }#P1
    {for (b in 1:7)
    {
      {dections<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Basins==b)
      if(nrow(dections)>0)
        Data_antibiotic_Num_Sample_Pv2[a,b]<-log10(nrow(dections)/Basin_area1[b,1]*10000000)
      else
        Data_antibiotic_Num_Sample_Pv2[a,b]<-0
      }
      {
        dections_A<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Basins==b,Data_Sample$Environmental_media<5)
        if(nrow(dections_A)>0)
          Data_antibiotic_Num_Sample_Pv2_A[a,b]<-log10(nrow(dections_A)/Basin_area1[b,1]*10000000)
        else
          Data_antibiotic_Num_Sample_Pv2_A[a,b]<-0
      }
      {
        dections_S<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Basins==b,Data_Sample$Environmental_media>4)
        if(nrow(dections_S)>0)
          Data_antibiotic_Num_Sample_Pv2_S[a,b]<-log10(nrow(dections_S)/Basin_area1[b,1]*10000000)
        else
          Data_antibiotic_Num_Sample_Pv2_S[a,b]<-0
      }
      Data_antibiotic_Num_Sample_Pv1_1[a,j]<- sum(Data_antibiotic_Num_Sample_Pv1[a,1:8])
      Data_antibiotic_Num_Sample_Pv2_1[a,j]<- sum(Data_antibiotic_Num_Sample_Pv2[a,1:7])
      Data_antibiotic_Num_Sample_Pv1_A_1[a,j]<-sum(Data_antibiotic_Num_Sample_Pv1_A[a,1:4])
      Data_antibiotic_Num_Sample_Pv1_S_1[a,j]<-sum(Data_antibiotic_Num_Sample_Pv1_S[a,1:4])
      Data_antibiotic_Num_Sample_Pv2_A_1[a,j]<-sum(Data_antibiotic_Num_Sample_Pv2_A[a,1:7])
      Data_antibiotic_Num_Sample_Pv2_S_1[a,j]<-sum(Data_antibiotic_Num_Sample_Pv2_S[a,1:7])
      
    }}#Pv2
    {
      O_A<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Environmental_media<5)
      
      if(nrow(O_A)>3)
        
        Data_antibiotic_Num_Sample_O1[a,1]<-quantile(log10(O_A$Concentration), probs = 0.95)
      else
        Data_antibiotic_Num_Sample_O1[a,1]<- quantile(log10(Data_Sample$Concentration), probs = 0.01)
      
      O_S<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Environmental_media>4)
      if(nrow(O_S)>3)
        
        Data_antibiotic_Num_Sample_O1[a,2]<-quantile(log10(O_S$Concentration), probs = 0.95)
      else
        Data_antibiotic_Num_Sample_O1[a,2]<- quantile(log10(Data_Sample$Concentration), probs = 0.01)
      
      Data_antibiotic_Num_Sample_O1_A[a,j]<- Data_antibiotic_Num_Sample_O1[a,1]
      Data_antibiotic_Num_Sample_O1_S[a,j]<- Data_antibiotic_Num_Sample_O1[a,2]
    }#O1
    {
      O2_A<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Environmental_media<5)
      O_A1<-filter(Data_Sample, Data_Sample$Environmental_media<5)
      O_PNEC_A<-filter(O2_A, O2_A$Concentration> as.numeric(PNEC[a,1])/median(PNEC2$PNEC_A)*median(O_A1$Concentration))
      
      if(nrow(O2_A)>3)
        Data_antibiotic_Num_Sample_O2[a,1]<- nrow(O_PNEC_A)/nrow(O2_A)
      else
        Data_antibiotic_Num_Sample_O2[a,1]<-0
      
      O2_S<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Environmental_media>4)
      O_S1<-filter(Data_Sample, Data_Sample$Environmental_media>4)
      O_PNEC_S<-filter(O2_S, O2_S$Concentration>as.numeric(PNEC[a,2])/median(PNEC2$PNEC_S)*median(O_S1$Concentration))
      if(nrow(O2_S)>3)
        Data_antibiotic_Num_Sample_O2[a,2]<-nrow(O_PNEC_S)/nrow(O2_S)
      else
        Data_antibiotic_Num_Sample_O2[a,2]<- 0
      
      Data_antibiotic_Num_Sample_O2_A[a,j]<- Data_antibiotic_Num_Sample_O2[a,1]
      Data_antibiotic_Num_Sample_O2_S[a,j]<- Data_antibiotic_Num_Sample_O2[a,2]
    }#O2
  }
  
}

for(f in 1:110){
  
  
  Data_antibiotic_Num_Sample_R0.95[f,1]<-mean(Data_antibiotic_Num_Sample_Pv1_1[f,1:27])
  Data_antibiotic_Num_Sample_R0.95[f,2]<-sd(Data_antibiotic_Num_Sample_Pv1_1[f,1:27])/mean(Data_antibiotic_Num_Sample_Pv1_1[f,1:27])
  
  Data_antibiotic_Num_Sample_R0.95[f,3]<-mean(Data_antibiotic_Num_Sample_Pv2_1[f,1:27])
  Data_antibiotic_Num_Sample_R0.95[f,4]<-sd(Data_antibiotic_Num_Sample_Pv2_1[f,1:27])/mean(Data_antibiotic_Num_Sample_Pv2_1[f,1:27])
  
  
  Data_antibiotic_Num_Sample_R0.95[f,5]<-mean(Data_antibiotic_Num_Sample_O1_A[f,1:27])
  Data_antibiotic_Num_Sample_R0.95[f,6]<-sd(Data_antibiotic_Num_Sample_O1_A[f,1:27])/abs(mean(Data_antibiotic_Num_Sample_O1_A[f,1:27]))
  
  Data_antibiotic_Num_Sample_R0.95[f,7]<-mean(Data_antibiotic_Num_Sample_O1_S[f,1:27])
  Data_antibiotic_Num_Sample_R0.95[f,8]<-sd(Data_antibiotic_Num_Sample_O1_S[f,1:27])/abs(mean(Data_antibiotic_Num_Sample_O1_S[f,1:27]))
  
  Data_antibiotic_Num_Sample_R0.95[f,9]<-mean(Data_antibiotic_Num_Sample_O2_A[f,1:27])
  Data_antibiotic_Num_Sample_R0.95[f,10]<-sd(Data_antibiotic_Num_Sample_O2_A[f,1:27])/abs(mean(Data_antibiotic_Num_Sample_O2_A[f,1:27]))
  
  Data_antibiotic_Num_Sample_R0.95[f,11]<-mean(Data_antibiotic_Num_Sample_O2_S[f,1:27])
  Data_antibiotic_Num_Sample_R0.95[f,12]<-sd(Data_antibiotic_Num_Sample_O2_S[f,1:27])/abs(mean(Data_antibiotic_Num_Sample_O2_S[f,1:27]))
  
  Data_antibiotic_Num_Sample_R0.95[f,13]<-mean(Data_antibiotic_Num_Sample_Pv1_A_1[f,1:27])
  Data_antibiotic_Num_Sample_R0.95[f,14]<-sd(Data_antibiotic_Num_Sample_Pv1_A_1[f,1:27])/abs(mean(Data_antibiotic_Num_Sample_O2_S[f,1:27]))
  
  Data_antibiotic_Num_Sample_R0.95[f,15]<-mean(Data_antibiotic_Num_Sample_Pv1_S_1[f,1:27])
  Data_antibiotic_Num_Sample_R0.95[f,16]<-sd(Data_antibiotic_Num_Sample_Pv1_S_1[f,1:27])/abs(mean(Data_antibiotic_Num_Sample_O2_S[f,1:27]))
  
  Data_antibiotic_Num_Sample_R0.95[f,17]<-mean(Data_antibiotic_Num_Sample_Pv2_A_1[f,1:27])
  Data_antibiotic_Num_Sample_R0.95[f,18]<-sd(Data_antibiotic_Num_Sample_Pv2_A_1[f,1:27])/abs(mean(Data_antibiotic_Num_Sample_O2_S[f,1:27]))
  
  Data_antibiotic_Num_Sample_R0.95[f,19]<-mean(Data_antibiotic_Num_Sample_Pv2_S_1[f,1:27])
  Data_antibiotic_Num_Sample_R0.95[f,20]<-sd(Data_antibiotic_Num_Sample_Pv2_S_1[f,1:27])/abs(mean(Data_antibiotic_Num_Sample_O2_S[f,1:27]))
  
  
}#Mean&SD
Data_antibiotic_Num_Sample_R0.95<-Data_antibiotic_Num_Sample_R0.95[-c(101,92,93,53,100),]

{
  MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,1])
  MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,1])
  Data_antibiotic_Num_Sample_R0.95[,1]<-(Data_antibiotic_Num_Sample_R0.95[,1]-MIN)/(MAX-MIN)
  
  
  MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,3])
  MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,3])
  Data_antibiotic_Num_Sample_R0.95[,3]<-(Data_antibiotic_Num_Sample_R0.95[,3]-MIN)/(MAX-MIN)
  
  
  MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,5])
  MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,5])
  Data_antibiotic_Num_Sample_R0.95[,5]<-(Data_antibiotic_Num_Sample_R0.95[,5]-MIN)/(MAX-MIN)
  
  MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,7])
  MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,7])
  Data_antibiotic_Num_Sample_R0.95[,7]<-(Data_antibiotic_Num_Sample_R0.95[,7]-MIN)/(MAX-MIN)
  
  MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,9])
  MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,9])
  Data_antibiotic_Num_Sample_R0.95[,9]<-(Data_antibiotic_Num_Sample_R0.95[,9]-MIN)/(MAX-MIN)
  
  MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,11])
  MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,11])
  Data_antibiotic_Num_Sample_R0.95[,11]<-(Data_antibiotic_Num_Sample_R0.95[,11]-MIN)/(MAX-MIN)
  
  MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,13])
  MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,13])
  Data_antibiotic_Num_Sample_R0.95[,13]<-(Data_antibiotic_Num_Sample_R0.95[,13]-MIN)/(MAX-MIN)
  
  MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,15])
  MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,15])
  Data_antibiotic_Num_Sample_R0.95[,15]<-(Data_antibiotic_Num_Sample_R0.95[,15]-MIN)/(MAX-MIN)
  
  MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,17])
  MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,17])
  Data_antibiotic_Num_Sample_R0.95[,17]<-(Data_antibiotic_Num_Sample_R0.95[,17]-MIN)/(MAX-MIN)
  
  MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,19])
  MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,19])
  Data_antibiotic_Num_Sample_R0.95[,19]<-(Data_antibiotic_Num_Sample_R0.95[,19]-MIN)/(MAX-MIN)
  
  
  
  colnames(Data_antibiotic_Num_Sample_R0.95)<-c("Pv1","Pv1_SD","Pv2","Pv2_SD","O1_A","O1_A_SD","O1_S","O1_S_SD","O2_A","O2_A_SD","O2_S","O2_S_SD",
                                                "Pv1_A","Pv1_A_SD","Pv1_S","Pv1_S_SD","Pv2_A","Pv2_A_SD","Pv2_S","Pv2_S_SD")
  
  
}#归一化
Data_antibiotic_Num_Sample_R0.95<-as.data.frame(Data_antibiotic_Num_Sample_R0.95)
PBT<-PBT1
PBT<-mutate(PBT,log_BCF=log10(BCF))
PBT<-mutate(PBT,log_Green_Algae=log10(PBT$`Green Algae`))
PBT<-mutate(PBT,log_Daphnid=log10(PBT$Daphnid))
PBT<-mutate(PBT,log_Fish=log10(PBT$Fish))
PBT<-mutate(PBT,Bioaccumulation=(log_BCF-min(PBT$log_BCF))/(max(PBT$log_BCF)-min(PBT$log_BCF)))
PBT<-mutate(PBT,Persistence=(max(PBT$BIOWIN3)-PBT$BIOWIN3)/(max(PBT$BIOWIN3)-min(PBT$BIOWIN3)))
PBT<-mutate(PBT,Toxicity_Green_Algae=(log_Green_Algae-min(PBT$log_Green_Algae))/(max(PBT$log_Green_Algae)-min(PBT$log_Green_Algae)))
PBT<-mutate(PBT,Toxicity_log_Daphnid=(log_Daphnid-min(PBT$log_Daphnid))/(max(PBT$log_Daphnid)-min(PBT$log_Daphnid)))
PBT<-mutate(PBT,Toxicity_log_Fish=(log_Fish-min(PBT$log_Fish))/(max(PBT$log_Fish)-min(PBT$log_Fish)))
PvO<-as.data.frame(Data_antibiotic_Num_Sample_R0.95)
PBT<-bind_cols(PBT,PvO)


#PvOPBT_A
{PBT<-mutate(PBT,Pv_Mean=(PBT$Pv1_A+PBT$Pv2_A)/2)
PBT<-mutate(PBT,Pv_Score=(Pv_Mean-min(PBT$Pv_Mean))/(max(PBT$Pv_Mean)-min(PBT$Pv_Mean)))
PBT<-mutate(PBT,O_Mean=(PBT$O1_A+PBT$O2_A)/2)
PBT<-mutate(PBT,O_Score=(O_Mean-min(PBT$O_Mean))/(max(PBT$O_Mean)-min(PBT$O_Mean)))
PBT<-mutate(PBT,T_Mean=(PBT$Toxicity_Green_Algae+PBT$Toxicity_log_Daphnid+PBT$Toxicity_log_Fish)/3)
PBT<-mutate(PBT,T_Score=(T_Mean-min(PBT$T_Mean))/(max(PBT$T_Mean)-min(PBT$T_Mean)))
PBT<-mutate(PBT,PBT_Mean=(PBT$Bioaccumulation+PBT$Persistence+PBT$T_Score)/3)
PBT<-mutate(PBT,PBT_Score=(PBT_Mean-min(PBT$PBT_Mean))/(max(PBT$PBT_Mean)-min(PBT$PBT_Mean)))
PBT<-mutate(PBT,PvOPBT_A_Score=(PBT$Pv_Score+PBT$O_Score+PBT$PBT_Score)/3)
PvOPBT_A<-PBT

PvOPBT_A_Order<-PvOPBT_A[order(-PvOPBT_A$PvOPBT_A_Score),]

PvOPBT_A_Order<-PvOPBT_A_Order[,c(2,4,60,62,66,67)]}
#PvOPBT_S
{PBT<-mutate(PBT,Pv_Mean=(PBT$Pv1_S+PBT$Pv2_S)/2)
  PBT<-mutate(PBT,Pv_Score=(Pv_Mean-min(PBT$Pv_Mean))/(max(PBT$Pv_Mean)-min(PBT$Pv_Mean)))
  PBT<-mutate(PBT,O_Mean=(PBT$O1_S+PBT$O2_S)/2)
  PBT<-mutate(PBT,O_Score=(O_Mean-min(PBT$O_Mean))/(max(PBT$O_Mean)-min(PBT$O_Mean)))
  PBT<-mutate(PBT,T_Mean=(PBT$Toxicity_Green_Algae+PBT$Toxicity_log_Daphnid+PBT$Toxicity_log_Fish)/3)
  PBT<-mutate(PBT,T_Score=(T_Mean-min(PBT$T_Mean))/(max(PBT$T_Mean)-min(PBT$T_Mean)))
  PBT<-mutate(PBT,PBT_Mean=(PBT$Bioaccumulation+PBT$Persistence+PBT$T_Score)/3)
  PBT<-mutate(PBT,PBT_Score=(PBT_Mean-min(PBT$PBT_Mean))/(max(PBT$PBT_Mean)-min(PBT$PBT_Mean)))
  PBT<-mutate(PBT,PvOPBT_S_Score=(PBT$Pv_Score+PBT$O_Score+PBT$PBT_Score)/3)
  PvOPBT_S<-PBT
  PvOPBT_S_Order<-PvOPBT_S[order(-PvOPBT_S$PvOPBT_S_Score),]
  PvOPBT_S_Order<-PvOPBT_S_Order[,c(2,4,60,62,66,68)]
  }

colnames(PvOPBT_A_Order)<-c("Classifications","Antibiotics","Pv Score","O Score","PBT Score","PvOPBT Score")
PvOPBT_A_Order$Classifications = gsub("1Macrolides" , "Macrolides", PvOPBT_A_Order$Classifications )
PvOPBT_A_Order$Classifications = gsub("2Quinolones" , "Quinolones", PvOPBT_A_Order$Classifications )
PvOPBT_A_Order$Classifications = gsub("3Tetracyclines" , "Tetracyclines", PvOPBT_A_Order$Classifications )
PvOPBT_A_Order$Classifications = gsub("4Sulfonamides" , "Sulfonamides", PvOPBT_A_Order$Classifications )
PvOPBT_A_Order$Classifications = gsub("5Other" , "Others", PvOPBT_A_Order$Classifications )
PvOPBT_A_Order$Classifications = gsub("6Unclassified" , "Unclassified", PvOPBT_A_Order$Classifications )
PvOPBT_A_Order$Classifications = gsub("7Aminoglycosides" , "Aminoglycosides", PvOPBT_A_Order$Classifications )
PvOPBT_A_Order$Classifications = gsub("8β–Lactam" , "β–Lactam", PvOPBT_A_Order$Classifications )
PvOPBT_A_Order<-add_column(PvOPBT_A_Order,Rankings=1:105)

colnames(PvOPBT_S_Order)<-c("Classifications","Antibiotics","Pv Score","O Score","PBT Score","PvOPBT Score")
PvOPBT_S_Order$Classifications = gsub("1Macrolides" , "Macrolides", PvOPBT_S_Order$Classifications )
PvOPBT_S_Order$Classifications = gsub("2Quinolones" , "Quinolones", PvOPBT_S_Order$Classifications )
PvOPBT_S_Order$Classifications = gsub("3Tetracyclines" , "Tetracyclines", PvOPBT_S_Order$Classifications )
PvOPBT_S_Order$Classifications = gsub("4Sulfonamides" , "Sulfonamides", PvOPBT_S_Order$Classifications )
PvOPBT_S_Order$Classifications = gsub("5Other" , "Others", PvOPBT_S_Order$Classifications )
PvOPBT_S_Order$Classifications = gsub("6Unclassified" , "Unclassified", PvOPBT_S_Order$Classifications )
PvOPBT_S_Order$Classifications = gsub("7Aminoglycosides" , "Aminoglycosides", PvOPBT_S_Order$Classifications )
PvOPBT_S_Order$Classifications = gsub("8β–Lactam" , "β–Lactam", PvOPBT_S_Order$Classifications )
PvOPBT_S_Order<-add_column(PvOPBT_S_Order,Rankings=1:105)
