## PvOPBT Method
load("PvOPBT Method.RData")
load("PvOPBT_Order_Score.Rdata")
library(ggplot2)
library(readxl)
library(gcookbook)
library(MASS)
library(scales)   
library(pheatmap)
library(dplyr)
library(FactoMineR)
library(base)
library(reshape2)
library(RColorBrewer)
library(circlize)
library(viridis)
library(reshape2)
library(ggraph)
library(igraph)
library(tidyverse)
library(RColorBrewer)
library(SuppDists)
library(ggsignif)
library(ggpubr)
library(ggalluvial)
#A randomly sampled scaling ratio 0.95 times (Numbers of data:14776)
#repeat 27times
A<-PvOPBT_Order_Score[order(PvOPBT_Order_Score$Antibiotics),]
PvOPBT_SD<- A[,c(1,2)]
for(c in 1:7){#SD=7
  Data_antibiotic_Num_Sample_R0.95<-matrix(nrow = 110,ncol =12)
  Data_antibiotic_Num_Sample_Pv1_1<-matrix(nrow = 110,ncol =27)#Pv1 sub-criteria
  Data_antibiotic_Num_Sample_Pv2_1<-matrix(nrow = 110,ncol =27)#Pv2 sub-criteria
  Data_antibiotic_Num_Sample_O1_A<-matrix(nrow = 110,ncol =27)#O1 sub-criteria in aqueous phase
  Data_antibiotic_Num_Sample_O1_S<-matrix(nrow = 110,ncol =27)#O1 sub-criteria in solid phase
  Data_antibiotic_Num_Sample_O2_A<-matrix(nrow = 110,ncol =27)#O2 sub-criteria in aqueous phase
  Data_antibiotic_Num_Sample_O2_S<-matrix(nrow = 110,ncol =27)#O2 sub-criteria in solid phase
  for(j in 1:27)#repeat 27 times
  {
    Data_Sample<- Data_antibiotic_Num2[sample(nrow(Data_antibiotic_Num2),14776),]
    #A randomly sampled scaling ratio 0.95 times
    Data_antibiotic_Num_Sample_Pv1<-matrix(nrow = 110,ncol =8 )
    Data_antibiotic_Num_Sample_Pv2<-matrix(nrow = 110,ncol =7 )
    Data_antibiotic_Num_Sample_O1<-matrix(nrow = 110,ncol =2 )
    Data_antibiotic_Num_Sample_O2<-matrix(nrow = 110,ncol =2 )
    for(a in 1:110)#Antibiotics
    {
      for(m in 1:8)#Environmental media
      {
        media<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Environmental_media==m)
        if(nrow(media)>0)
          Data_antibiotic_Num_Sample_Pv1[a,m]<-1
        else
          Data_antibiotic_Num_Sample_Pv1[a,m]<-0
      }#P1
      {for (b in 1:7)#Basins
      {
        dections<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Basins==b)
        
        if(nrow(dections)>0)
          Data_antibiotic_Num_Sample_Pv2[a,b]<-log10(nrow(dections)/Basin_area1[b,1]*10000000)
        else
          Data_antibiotic_Num_Sample_Pv2[a,b]<-0
      }
        Data_antibiotic_Num_Sample_Pv1_1[a,j]<- sum(Data_antibiotic_Num_Sample_Pv1[a,1:8])
        Data_antibiotic_Num_Sample_Pv2_1[a,j]<- sum(Data_antibiotic_Num_Sample_Pv2[a,1:7])
      }#P2
      {
        O_A<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Environmental_media<5)
        if(nrow(O_A)>3)
          Data_antibiotic_Num_Sample_O1[a,1]<-quantile(log10(O_A$Concentration), probs = 0.95)
        else
          Data_antibiotic_Num_Sample_O1[a,1]<- quantile(log10(Data_Sample$Concentration), probs = 0.01)
        
        O_S<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Environmental_media>4)
        if(nrow(O_S)>3)
          Data_antibiotic_Num_Sample_O1[a,2]<-quantile(log10(O_S$Concentration), probs = 0.95)
        else
          Data_antibiotic_Num_Sample_O1[a,2]<- quantile(log10(Data_Sample$Concentration), probs = 0.01)
        
        Data_antibiotic_Num_Sample_O1_A[a,j]<- Data_antibiotic_Num_Sample_O1[a,1]
        Data_antibiotic_Num_Sample_O1_S[a,j]<- Data_antibiotic_Num_Sample_O1[a,2]
      }#O1
      {
        O2_A<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Environmental_media<5)
        O_A1<-filter(Data_Sample, Data_Sample$Environmental_media<5)
        O_PNEC_A<-filter(O2_A, O2_A$Concentration > as.numeric(PNEC[a,1])/median(PNEC2$PNEC_A)*median(O_A1$Concentration))
        if(nrow(O2_A)>3)
          Data_antibiotic_Num_Sample_O2[a,1]<- nrow(O_PNEC_A)/nrow(O2_A)
        else
          Data_antibiotic_Num_Sample_O2[a,1]<-0 
        
        O2_S<-filter(Data_Sample, Data_Sample$Antibiotics==a, Data_Sample$Environmental_media>4)
        O_S1<-filter(Data_Sample, Data_Sample$Environmental_media>4)
        O_PNEC_S<-filter(O2_S, O2_S$Concentration>as.numeric(PNEC[a,2])/median(PNEC2$PNEC_S)*median(O_S1$Concentration))
        
        if(nrow(O2_S)>3)
          Data_antibiotic_Num_Sample_O2[a,2]<-nrow(O_PNEC_S)/nrow(O2_S)
        else
          Data_antibiotic_Num_Sample_O2[a,2]<- 0
        
        Data_antibiotic_Num_Sample_O2_A[a,j]<- Data_antibiotic_Num_Sample_O2[a,1]
        Data_antibiotic_Num_Sample_O2_S[a,j]<- Data_antibiotic_Num_Sample_O2[a,2] 
      }#O2
    }
    
  }
  
  for(f in 1:110){
    Data_antibiotic_Num_Sample_R0.95[f,1]<-mean(Data_antibiotic_Num_Sample_Pv1_1[f,1:27])
    Data_antibiotic_Num_Sample_R0.95[f,2]<-sd(Data_antibiotic_Num_Sample_Pv1_1[f,1:27])/mean(Data_antibiotic_Num_Sample_Pv1_1[f,1:27])
    
    Data_antibiotic_Num_Sample_R0.95[f,3]<-mean(Data_antibiotic_Num_Sample_Pv2_1[f,1:27])
    Data_antibiotic_Num_Sample_R0.95[f,4]<-sd(Data_antibiotic_Num_Sample_Pv2_1[f,1:27])/mean(Data_antibiotic_Num_Sample_Pv2_1[f,1:27])
    
    Data_antibiotic_Num_Sample_R0.95[f,5]<-mean(Data_antibiotic_Num_Sample_O1_A[f,1:27])
    Data_antibiotic_Num_Sample_R0.95[f,6]<-sd(Data_antibiotic_Num_Sample_O1_A[f,1:27])/abs(mean(Data_antibiotic_Num_Sample_O1_A[f,1:27]))
    
    Data_antibiotic_Num_Sample_R0.95[f,7]<-mean(Data_antibiotic_Num_Sample_O1_S[f,1:27])
    Data_antibiotic_Num_Sample_R0.95[f,8]<-sd(Data_antibiotic_Num_Sample_O1_S[f,1:27])/abs(mean(Data_antibiotic_Num_Sample_O1_S[f,1:27]))
    
    Data_antibiotic_Num_Sample_R0.95[f,9]<-mean(Data_antibiotic_Num_Sample_O2_A[f,1:27])
    Data_antibiotic_Num_Sample_R0.95[f,10]<-sd(Data_antibiotic_Num_Sample_O2_A[f,1:27])/abs(mean(Data_antibiotic_Num_Sample_O2_A[f,1:27]))
    
    Data_antibiotic_Num_Sample_R0.95[f,11]<-mean(Data_antibiotic_Num_Sample_O2_S[f,1:27])
    Data_antibiotic_Num_Sample_R0.95[f,12]<-sd(Data_antibiotic_Num_Sample_O2_S[f,1:27])/abs(mean(Data_antibiotic_Num_Sample_O2_S[f,1:27]))
  }#Mean&SD
  Data_antibiotic_Num_Sample_R0.95<-Data_antibiotic_Num_Sample_R0.95[-c(101,92,93,53,100),]
  
  {
    MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,1])
    MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,1])
    Data_antibiotic_Num_Sample_R0.95[,1]<-(Data_antibiotic_Num_Sample_R0.95[,1]-MIN)/(MAX-MIN)
    
    
    MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,3])
    MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,3])
    Data_antibiotic_Num_Sample_R0.95[,3]<-(Data_antibiotic_Num_Sample_R0.95[,3]-MIN)/(MAX-MIN)
    
    
    MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,5])
    MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,5])
    Data_antibiotic_Num_Sample_R0.95[,5]<-(Data_antibiotic_Num_Sample_R0.95[,5]-MIN)/(MAX-MIN)
    
    MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,7])
    MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,7])
    Data_antibiotic_Num_Sample_R0.95[,7]<-(Data_antibiotic_Num_Sample_R0.95[,7]-MIN)/(MAX-MIN)
    
    MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,9])
    MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,9])
    Data_antibiotic_Num_Sample_R0.95[,9]<-(Data_antibiotic_Num_Sample_R0.95[,9]-MIN)/(MAX-MIN)
    
    MAX<-max(Data_antibiotic_Num_Sample_R0.95[1:105,11])
    MIN<-min(Data_antibiotic_Num_Sample_R0.95[1:105,11])
    Data_antibiotic_Num_Sample_R0.95[,11]<-(Data_antibiotic_Num_Sample_R0.95[,11]-MIN)/(MAX-MIN)
    colnames(Data_antibiotic_Num_Sample_R0.95)<-c("Pv1","Pv1_SD","Pv2","Pv2_SD","O1_A","O1_A_SD","O1_S","O1_S_SD","O2_A","O2_A_SD","O2_S","O2_S_SD")
  }#Utility function
  
  
  #Score
  PBT<-PBT1
  PBT<-mutate(PBT,log_BCF=log10(BCF))
  PBT<-mutate(PBT,log_Green_Algae=log10(PBT$`Green Algae`))
  PBT<-mutate(PBT,log_Daphnid=log10(PBT$Daphnid))
  PBT<-mutate(PBT,log_Fish=log10(PBT$Fish))
  PBT<-mutate(PBT,Bioaccumulation=(log_BCF-min(PBT$log_BCF))/(max(PBT$log_BCF)-min(PBT$log_BCF)))
  PBT<-mutate(PBT,Persistence=(max(PBT$BIOWIN3)-PBT$BIOWIN3)/(max(PBT$BIOWIN3)-min(PBT$BIOWIN3)))
  PBT<-mutate(PBT,Toxicity_Green_Algae=(log_Green_Algae-min(PBT$log_Green_Algae))/(max(PBT$log_Green_Algae)-min(PBT$log_Green_Algae)))
  PBT<-mutate(PBT,Toxicity_log_Daphnid=(log_Daphnid-min(PBT$log_Daphnid))/(max(PBT$log_Daphnid)-min(PBT$log_Daphnid)))
  PBT<-mutate(PBT,Toxicity_log_Fish=(log_Fish-min(PBT$log_Fish))/(max(PBT$log_Fish)-min(PBT$log_Fish)))
  PvO<-as.data.frame(Data_antibiotic_Num_Sample_R0.95)
  
  PBT<-bind_cols(PBT,PvO)
  
  PBT<-mutate(PBT,Pv_Mean=(PBT$Pv1+PBT$Pv2)/2)
  PBT<-mutate(PBT,Pv_Score=(Pv_Mean-min(PBT$Pv_Mean))/(max(PBT$Pv_Mean)-min(PBT$Pv_Mean)))
  PBT<-mutate(PBT,O_Mean=(PBT$O1_A+PBT$O1_S+PBT$O2_A+PBT$O2_S)/4)
  PBT<-mutate(PBT,O_Score=(O_Mean-min(PBT$O_Mean))/(max(PBT$O_Mean)-min(PBT$O_Mean)))
  PBT<-mutate(PBT,T_Mean=(PBT$Toxicity_Green_Algae+PBT$Toxicity_log_Daphnid+PBT$Toxicity_log_Fish)/3)
  PBT<-mutate(PBT,T_Score=(T_Mean-min(PBT$T_Mean))/(max(PBT$T_Mean)-min(PBT$T_Mean)))
  PBT<-mutate(PBT,PBT_Mean=(PBT$Bioaccumulation+PBT$Persistence+PBT$T_Score)/3)
  PBT<-mutate(PBT,PBT_Score=(PBT_Mean-min(PBT$PBT_Mean))/(max(PBT$PBT_Mean)-min(PBT$PBT_Mean)))
  PBT<-mutate(PBT,PvOPBT_Score=(PBT$Pv_Score+PBT$O_Score+PBT$PBT_Score)/3)
  
  PvOPBT<-PBT
  PvOPBT_Order<-PvOPBT[order(-PvOPBT$PvOPBT_Score),]
  PvOPBT_Order_Score<-PvOPBT_Order[,c(2,4,52,54,58,59)]
  colnames(PvOPBT_Order_Score)<-c("Classifications","Antibiotics","Pv Score","O Score","PBT Score","PvOPBT Score")
  PvOPBT_Order_Score$Classifications = gsub("1Macrolides" , "Macrolides", PvOPBT_Order_Score$Classifications )
  PvOPBT_Order_Score$Classifications = gsub("2Quinolones" , "Quinolones", PvOPBT_Order_Score$Classifications )
  PvOPBT_Order_Score$Classifications = gsub("3Tetracyclines" , "Tetracyclines", PvOPBT_Order_Score$Classifications )
  PvOPBT_Order_Score$Classifications = gsub("4Sulfonamides" , "Sulfonamides", PvOPBT_Order_Score$Classifications )
  PvOPBT_Order_Score$Classifications = gsub("5Other" , "Others", PvOPBT_Order_Score$Classifications )
  PvOPBT_Order_Score$Classifications = gsub("6Unclassified" , "Unclassified", PvOPBT_Order_Score$Classifications )
  PvOPBT_Order_Score$Classifications = gsub("7Aminoglycosides" , "Aminoglycosides", PvOPBT_Order_Score$Classifications )
  PvOPBT_Order_Score$Classifications = gsub("8β–Lactam" , "β–Lactam", PvOPBT_Order_Score$Classifications )
  PvOPBT_Order_Score<-add_column(PvOPBT_Order_Score,Rankings=1:105)
  save(PvOPBT_Order_Score,file="PvOPBT_Order_Score.Rdata")
  PvOPBT_Order_SD<-PvOPBT_Order_Score[order(PvOPBT_Order_Score$Antibiotics),]
  PvOPBT_SD<-bind_cols(PvOPBT_SD,PvOPBT_Order_SD[,7])}
  
 

## PvOPBT Results
# ```{r}
# load("PvOPBT_Order_Score.Rdata")
# options(digits=2)
# knitr::kable(PvOPBT_Order_Score, format="html")
# ```
## PvOPBT ranking of 105 candidate antibiotics based on the classifications of their chemical structure.

load("ggraph.Rdata")
mygraph <- graph_from_data_frame( edges, vertices = vertices, directed = TRUE )
cols <- c("105 Candidate Antibiotics"=	"#8DD3C7", "Group1"="#80B1D3",
          "Group2"="#FDB462", 
          "Macrolides"="#E41A1C",
          "Quinolones"="#377EB8",
          "Tetracyclines"=	"#4DAF4A",
          "Sulfonamides"=	"#984EA3",
          "Others"=	"#FF7F00",
          "Unclassified"=	"#A65628",
          "Aminoglycosides"	="#F781BF",
          "β-Lactam"=	"#999999")
cairo_pdf("PvOPBT_Order_all.pdf",width = 11,height=8.8,family="Times")
ggraph(mygraph, layout = 'dendrogram', circular = TRUE) + 
  geom_edge_diagonal(aes(colour=..index..)) +
  scale_edge_colour_distiller(palette = "Greys") +
  geom_node_text(aes(x = x*bujin, y=y*bujin,  angle = (angle-12),  label=name,color=group),
                 size=4, alpha=1) +
  geom_node_point(aes( x = x*1.05, y=y*1.05, fill=group, size=value), 
                  shape=vertices$alpha1,stroke=0.7,color='black',alpha=1) +
  scale_colour_manual(values= cols) +
  scale_fill_manual(values=  cols) +
  scale_size_continuous( range = c(0.1,7.5) ) +
  expand_limits(x = c(-1.5, 1.5), y = c(-1.5, 1.5))+
  theme_void() +
  theme(
    legend.position="right",
    plot.margin=unit(c(0,0,0,0),"cm")
  ) 
dev.off()


## Proportion of various classifications of antibiotics in four quartile intervals of PvOPBT ranking.


PvOPBT_Order_Score_Q1<-PvOPBT_Order_Score[1:26,]
PvOPBT_Order_Score_Q2<-PvOPBT_Order_Score[27:53,]
PvOPBT_Order_Score_Q3<-PvOPBT_Order_Score[54:79,]
PvOPBT_Order_Score_Q4<-PvOPBT_Order_Score[80:105,]
PvOPBT_Q <- matrix(nrow = 8,ncol =5)
colnames(PvOPBT_Q)<-c("Classification","Q1","Q2","Q3","Q4")
PvOPBT_Q<-as.data.frame(PvOPBT_Q)
PvOPBT_Q$Classification<-c("Sulfonamides",
                           "Quinolones",
                           "Macrolides",
                           "Tetracyclines",
                           "Unclassified",
                           "Others",
                           "β-Lactam",
                           "Aminoglycosides")

PvOPBT_Q[1,2]<-nrow(filter(PvOPBT_Order_Score_Q1,PvOPBT_Order_Score_Q1$Classifications==  "Sulfonamides"))
PvOPBT_Q[2,2]<-nrow(filter(PvOPBT_Order_Score_Q1,PvOPBT_Order_Score_Q1$Classifications==  "Quinolones"))
PvOPBT_Q[3,2]<-nrow(filter(PvOPBT_Order_Score_Q1,PvOPBT_Order_Score_Q1$Classifications==  "Macrolides"))
PvOPBT_Q[4,2]<-nrow(filter(PvOPBT_Order_Score_Q1,PvOPBT_Order_Score_Q1$Classifications==  "Tetracyclines"))
PvOPBT_Q[5,2]<-nrow(filter(PvOPBT_Order_Score_Q1,PvOPBT_Order_Score_Q1$Classifications==  "Unclassified"))
PvOPBT_Q[6,2]<-nrow(filter(PvOPBT_Order_Score_Q1,PvOPBT_Order_Score_Q1$Classifications==  "Others"))
PvOPBT_Q[7,2]<-nrow(filter(PvOPBT_Order_Score_Q1,PvOPBT_Order_Score_Q1$Classifications==  "β–Lactam"))
PvOPBT_Q[8,2]<-nrow(filter(PvOPBT_Order_Score_Q1,PvOPBT_Order_Score_Q1$Classifications==  "Aminoglycosides"))

PvOPBT_Q[1,3]<-nrow(filter(PvOPBT_Order_Score_Q2,PvOPBT_Order_Score_Q2$Classifications==  "Sulfonamides"))
PvOPBT_Q[2,3]<-nrow(filter(PvOPBT_Order_Score_Q2,PvOPBT_Order_Score_Q2$Classifications==  "Quinolones"))
PvOPBT_Q[3,3]<-nrow(filter(PvOPBT_Order_Score_Q2,PvOPBT_Order_Score_Q2$Classifications==  "Macrolides"))
PvOPBT_Q[4,3]<-nrow(filter(PvOPBT_Order_Score_Q2,PvOPBT_Order_Score_Q2$Classifications==  "Tetracyclines"))
PvOPBT_Q[5,3]<-nrow(filter(PvOPBT_Order_Score_Q2,PvOPBT_Order_Score_Q2$Classifications==  "Unclassified"))
PvOPBT_Q[6,3]<-nrow(filter(PvOPBT_Order_Score_Q2,PvOPBT_Order_Score_Q2$Classifications==  "Others"))
PvOPBT_Q[7,3]<-nrow(filter(PvOPBT_Order_Score_Q2,PvOPBT_Order_Score_Q2$Classifications==  "β–Lactam"))
PvOPBT_Q[8,3]<-nrow(filter(PvOPBT_Order_Score_Q2,PvOPBT_Order_Score_Q2$Classifications==  "Aminoglycosides"))

PvOPBT_Q[1,4]<-nrow(filter(PvOPBT_Order_Score_Q3,PvOPBT_Order_Score_Q3$Classifications==  "Sulfonamides"))
PvOPBT_Q[2,4]<-nrow(filter(PvOPBT_Order_Score_Q3,PvOPBT_Order_Score_Q3$Classifications==  "Quinolones"))
PvOPBT_Q[3,4]<-nrow(filter(PvOPBT_Order_Score_Q3,PvOPBT_Order_Score_Q3$Classifications==  "Macrolides"))
PvOPBT_Q[4,4]<-nrow(filter(PvOPBT_Order_Score_Q3,PvOPBT_Order_Score_Q3$Classifications==  "Tetracyclines"))
PvOPBT_Q[5,4]<-nrow(filter(PvOPBT_Order_Score_Q3,PvOPBT_Order_Score_Q3$Classifications==  "Unclassified"))
PvOPBT_Q[6,4]<-nrow(filter(PvOPBT_Order_Score_Q3,PvOPBT_Order_Score_Q3$Classifications==  "Others"))
PvOPBT_Q[7,4]<-nrow(filter(PvOPBT_Order_Score_Q3,PvOPBT_Order_Score_Q3$Classifications==  "β–Lactam"))
PvOPBT_Q[8,4]<-nrow(filter(PvOPBT_Order_Score_Q3,PvOPBT_Order_Score_Q3$Classifications==  "Aminoglycosides"))

PvOPBT_Q[1,5]<-nrow(filter(PvOPBT_Order_Score_Q4,PvOPBT_Order_Score_Q4$Classifications==  "Sulfonamides"))
PvOPBT_Q[2,5]<-nrow(filter(PvOPBT_Order_Score_Q4,PvOPBT_Order_Score_Q4$Classifications==  "Quinolones"))
PvOPBT_Q[3,5]<-nrow(filter(PvOPBT_Order_Score_Q4,PvOPBT_Order_Score_Q4$Classifications==  "Macrolides"))
PvOPBT_Q[4,5]<-nrow(filter(PvOPBT_Order_Score_Q4,PvOPBT_Order_Score_Q4$Classifications==  "Tetracyclines"))
PvOPBT_Q[5,5]<-nrow(filter(PvOPBT_Order_Score_Q4,PvOPBT_Order_Score_Q4$Classifications==  "Unclassified"))
PvOPBT_Q[6,5]<-nrow(filter(PvOPBT_Order_Score_Q4,PvOPBT_Order_Score_Q4$Classifications==  "Others"))
PvOPBT_Q[7,5]<-nrow(filter(PvOPBT_Order_Score_Q4,PvOPBT_Order_Score_Q4$Classifications==  "β–Lactam"))
PvOPBT_Q[8,5]<-nrow(filter(PvOPBT_Order_Score_Q4,PvOPBT_Order_Score_Q4$Classifications==  "Aminoglycosides"))

cairo_pdf("PvOPBT_all_chordDiagram.pdf",width = 8.5,height=8.5,family="Times")
mydata<-melt(PvOPBT_Q,id.vars='Classification')
mydata$variable = gsub("Q1" , "Q1 (High priority)", mydata$variable   )
mydata$variable  = gsub("Q2" , "Q2 (Medium priority)", mydata$variable  )
mydata$variable = gsub("Q3" , "Q3 (Low priority)", mydata$variable  )
mydata$variable  = gsub("Q4" , "Q4 (No priority)", mydata$variable  )
colnames(mydata) <- c("from","to","value") 

circos.par(start.degree = 183, gap.degree = 4, track.margin = c(-0.1, 0.1), points.overflow.warning = FALSE)
par(mar = rep(0, 4))

cols <- c("Q1 (High priority)"=	"#A50026", "Q2 (Medium priority)"="#FDAE61",
          "Q3 (Low priority)"="#A6D96A", 
          "Q4 (No priority)"="#006837", 
          "Macrolides"="#E41A1C",
          "Quinolones"="#377EB8",
          "Tetracyclines"=	"#4DAF4A",
          "Sulfonamides"=	"#984EA3",
          "Others"=	"#FF7F00",
          "Unclassified"=	"#A65628",
          "Aminoglycosides"	="#F781BF",
          "β-Lactam"=	"#999999")
chordDiagram(mydata,grid.col = cols,transparency = 0.5,directional=2,
             annotationTrack = "grid",annotationTrackHeight = c(0.05, 0.1),
             order=c( 
               "Macrolides",
               "Quinolones",
               "Tetracyclines",
               "Sulfonamides",
               "Others",
               "Unclassified",
               "Aminoglycosides",
               "β-Lactam","Q4 (No priority)","Q3 (Low priority)","Q2 (Medium priority)", 
               "Q1 (High priority)"))
circos.trackPlotRegion( track.index = 1,bg.border = NA,
                        panel.fun = function(x, y) {
                          xlim = get.cell.meta.data("xlim")
                          sector.index = get.cell.meta.data("sector.index")
                          circos.text(x =mean(xlim), y = 3.2, labels = sector.index, 
                                      cex = 1.2, niceFacing = T,facing ="bending",col=cols)
                          circos.axis( h = "top",major.at = seq(from = 0, to = xlim[2], 
                                                                by = ifelse(test = xlim[2]>15, yes = 10, no = 5)),
                                       minor.ticks = 1, labels.niceFacing = T)
                        })

dev.off()
cairo_pdf("PvOPBT_all_sankey1.pdf",width = 8,height=6,family="Times")
mydata<-melt(PvOPBT_Q,id.vars='Classification')
mydata<-melt(mydata,id.vars='value')
mydata$group<-rep(1:32,2)
colnames(mydata) <- c("weight","variable","classifiaction","group") 
mydata$classifiaction = gsub("Macrolides" , "1Macrolides", mydata$classifiaction  )
mydata$classifiaction = gsub("Quinolones" , "2Quinolones", mydata$classifiaction )
mydata$classifiaction = gsub("Tetracyclines" , "3Tetracyclines", mydata$classifiaction )
mydata$classifiaction = gsub("Sulfonamides" , "4Sulfonamides", mydata$classifiaction )
mydata$classifiaction = gsub("Others" , "5Others", mydata$classifiaction )
mydata$classifiaction = gsub("Unclassified" , "6Unclassified", mydata$classifiaction )
mydata$classifiaction = gsub("Aminoglycosides" , "7Aminoglycosides", mydata$classifiaction )
mydata$classifiaction = gsub("β-Lactam" , "8β–Lactam", mydata$classifiaction )
cols <- c("Q1"=	"#A50026", "Q2"="#FDAE61",
          "Q3"="#A6D96A", 
          "Q4"="#006837", 
          "1Macrolides"="#E41A1C",
          "2Quinolones"="#377EB8",
          "3Tetracyclines"=	"#4DAF4A",
          "4Sulfonamides"=	"#984EA3",
          "5Others"=	"#FF7F00",
          "6Unclassified"=	"#A65628",
          "7Aminoglycosides"	="#F781BF",
          "8β–Lactam"=	"#999999")
ggplot(mydata,
       aes(x = variable,y = weight,
           stratum = classifiaction, alluvium = group,
           fill = classifiaction, label = classifiaction)) +
  geom_flow(alpha = 0.5,width=1/3) +
  geom_stratum(alpha =1,width=1/3,color="grey30") +
  geom_text(stat = "stratum", size = 3.5,angle=0) +
  scale_fill_manual(values= cols)+ 
  theme_test()+
  theme(legend.position = "none",
        axis.text.y =element_blank(),
        axis.line = element_blank(),
        axis.ticks =element_blank() )
dev.off()

## PvOPBT ranking scores for the antibiotics in the top quartile.


mydata<-melt(PvOPBT_Order_Score_Q1,id.vars='Antibiotics')
mydata<-mydata[c(27:104),]
mydata[,3]<-as.numeric(mydata$value)
mytheme<-theme_light()+theme(
  legend.position = "none",
  text =element_text(color="black"),
  strip.text = element_text(size = rel(1.2),colour = "black"),
  axis.title=element_text(size=14,colour = "black"),
  axis.text = element_text(size=11,colour = "black"),
  legend.title=element_text(size=13,colour = "black"),
  legend.background = element_blank())
pdf("PvOPBT_all_Q1_Bar.pdf",width = 7.5,height=5,family="Times")
par(mar = c(10, 5, 5, 5) + .2) 
ggplot(mydata,aes(x=mydata$Antibiotics,y=mydata$value/3,fill=mydata$variable))+
  geom_bar(stat="identity",position="stack", color="black", width=0.7,size=0.25,alpha=1)+
  scale_fill_manual(values=brewer.pal(3,"Set3")[c(1:3)])+
  mytheme+theme(legend.position = c(0.92,0.83),axis.text.x  = 
                  element_text(angle = 60,hjust = 1.1,vjust = 1.1),legend.background = element_blank())+
  ylab("PvOPBT Score")+xlab("Antibiotics in the Top Quartile")+scale_x_discrete(limits=PvOPBT_Order_Score_Q1$Antibiotics)+
  labs(fill="Score (1/3)")+ylim(0,.85)
dev.off()

mydata<-melt(PvOPBT_Order_Score,id.vars='Antibiotics')
mydata<-mydata[c(106:420),]
mydata[,3]<-as.numeric(mydata$value)
Q<-rep(c(rep("Q1",each=26),rep("Q2",each=27),rep("Q3",each=26),rep("Q4",each=26)),time=3)
mydata<-add_column(mydata,Q=Q)
mytheme<-theme_light()+theme(
  legend.position = "none",
  text =element_text(color="black"),
  strip.text = element_text(size = rel(1.2),colour = "black"),
  axis.title=element_text(size=14,colour = "black"),
  axis.text = element_text(size=11,colour = "black"),
  legend.title=element_text(size=13,colour = "black"),
  legend.background = element_blank())
pdf("PvOPBT_all_Bar.pdf",width = 12,height=5,family="Times")
par(mar = c(10, 5, 5, 5) + .2) 
ggplot(mydata,aes(x=reorder(Antibiotics,value),y=value/3,fill=variable))+
  geom_bar(stat="identity",position="stack", color="black", width=0.5,size=0.25,alpha=1)+
  scale_fill_manual(values=brewer.pal(3,"Set3")[c(1:3)])+
  mytheme+theme(legend.position = c(0.95,0.8),axis.text.x  = 
                  element_text(angle = 90,hjust = 1,vjust =.5),legend.background = element_blank())+
  ylab("PvOPBT Score")+xlab("Antibiotics")+
  labs(fill="Score (1/3)")+facet_wrap(~Q, nrow=1,scale = "free_y")+coord_flip()
dev.off()


## Calculated uncertainty range of the individual antibiotics.


PvOPBT_SD<-PvOPBT_SD[order(PvOPBT_SD$Rankings...3),]
PvOPBT_Order_SD<-PvOPBT_SD
max_min<-matrix(nrow = 105,ncol =2)
for(f in 1:105){
  max_min[f,1]<-min(PvOPBT_Order_SD[f,3:9])
  max_min[f,2]<-max(PvOPBT_Order_SD[f,3:9])
}
max_min<-as.data.frame(max_min)
PvOPBT_Order_SD2<-bind_cols(PvOPBT_Order_SD,max_min)
PvOPBT_Order_SD2<-PvOPBT_Order_SD2[,-c(3:9)]

Q<-matrix(nrow = 105,ncol =3)
Q[1:26,1]<-"Q1 (High priority)"
Q[27:53,1]<-"Q2 (Medium priority)"
Q[54:79,1]<-"Q3 (Low priority)"
Q[80:105,1]<-"Q4 (No priority)"
Q[1:105,2]<-"Min"
Q[1:105,3]<-"Max"
Q<-as.data.frame(Q)
a<-bind_cols(PvOPBT_Order_SD2[,c(1,2,3)],Q[,1:2])
b<-bind_cols(PvOPBT_Order_SD2[,c(1,2,4)],Q[,c(1,3)])
colnames(a)<-c("Classifications","Antibiotics","Value","Q","Var")
colnames(b)<-c("Classifications","Antibiotics","Value","Q","Var")
PvOPBT_SD2<-bind_rows(a,b)

pdf("PvOPBT_SD.pdf",width =10,height=8,family="Times")
par(mar = c(10, 5, 5, 5) + .2) 
ggplot(PvOPBT_SD2, aes(x=Value,y=reorder(PvOPBT_SD2$Antibiotics,PvOPBT_SD2$Value),fill=Var)) +
  geom_line(aes(group = Antibiotics)) +
  geom_point(shape=21,size=4,colour="black",position = position_jitterdodge(jitter.width = 0, jitter.height = -0.3,
                                                                            dodge.width = -0.3, seed = NA),alpha=1)+
  scale_fill_manual(values=c("#36BED9", "#FC4E07","#00AFBB"),limits=c("Min","Max"))+mytheme+
  theme(
    strip.text = element_text(size = rel(1.2),colour = "black"),
    axis.title=element_text(size=14,colour = "black"),
    axis.text = element_text(size=11,colour = "black"),
    legend.title=element_text(size=13,colour = "black"),
    legend.background = element_blank(),
    legend.position = c(0.92,0.07)
  )+
  ylab("Antibiotics")+xlab("PvOPBT Ranking")+labs(fill="Ranking Range")+
  facet_wrap(~PvOPBT_SD2$Q,scales = "free",nrow = 2)
dev.off()

## Density distribution of the environmental concentrations of antibiotics, PNEC, and PNECf.


Data_Sample_A<-filter(Data_Sample,Data_Sample$Environmental_media==c(1,2,3,4))
Data_Sample_A<-melt(Data_Sample_A)
Data_Sample_A<-filter(Data_Sample_A,Data_Sample_A$variable=="Concentration")
Data_antibiotic_PNEC_A<-melt(PNEC2)
Data_antibiotic_PNEC_A<-filter(Data_antibiotic_PNEC_A,Data_antibiotic_PNEC_A$variable=="PNEC_A")
Data_antibiotic_PNEC_A2<-Data_antibiotic_PNEC_A
Data_antibiotic_PNEC_A2[,2]<-Data_antibiotic_PNEC_A[,2]/median(Data_antibiotic_PNEC_A$value)*median(Data_Sample_A$value)
Data_antibiotic_and_PNEC_A<-bind_rows(Data_Sample_A,Data_antibiotic_PNEC_A)
Data_antibiotic_and_PNEC_A2<-bind_rows(Data_Sample_A,Data_antibiotic_PNEC_A2)
Data_antibiotic_and_PNEC_A$variable = gsub( "Concentration","Environmental Concentration", Data_antibiotic_and_PNEC_A$variable )
Data_antibiotic_and_PNEC_A2$variable = gsub( "Concentration","Environmental Concentration", Data_antibiotic_and_PNEC_A2$variable )
Data_antibiotic_and_PNEC_A$variable = gsub( "PNEC_A","PNEC", Data_antibiotic_and_PNEC_A$variable )
Data_antibiotic_and_PNEC_A2$variable = gsub( "PNEC_A","PNECf", Data_antibiotic_and_PNEC_A2$variable )
colnames(Data_antibiotic_and_PNEC_A)<-c("Aqueous Phase","value")
colnames(Data_antibiotic_and_PNEC_A2)<-c("Aqueous Phase","value")

cairo_pdf("Data_antibiotic_and_PNEC_A.pdf",width =5,height=4,family="Times")
ggplot(Data_antibiotic_and_PNEC_A,aes(x=log10(value),fill=`Aqueous Phase`))+geom_density(adjust=3,alpha=.3)+
  scale_fill_manual(values=brewer.pal(3,"Set2")[c(1:3)])+geom_vline(xintercept=log10(median(Data_antibiotic_PNEC_A$value)),size=.5,linetype="dashed",colour="#FC8D62")+
  geom_vline(xintercept=log10(median(Data_Sample_A$value)),size=.5,linetype="dashed",colour="#66C2A5")+
  ylab("Density")+xlab("log Concentrations (ng/L)")+mytheme+theme(legend.position = c(0.73,0.85))+scale_x_continuous(breaks = c(-4,-2,0,2,4,6,8,10))
dev.off()
cairo_pdf("Data_antibiotic_and_PNEC_A2.pdf",width =5,height=4,family="Times")
ggplot(Data_antibiotic_and_PNEC_A2,aes(x=log10(value),fill=`Aqueous Phase`))+geom_density(adjust=3,alpha=.3)+
  scale_fill_manual(values=brewer.pal(3,"Set2")[c(1:3)])+#geom_vline(xintercept=log(median(Data_antibiotic_PNEC_A2$value)),size=.5,linetype="dashed",colour="#FC8D62")+
  geom_vline(xintercept=log10(median(Data_Sample_A$value)),size=.5,linetype="dashed",colour="#8DA0CB")+
  ylab("Density")+xlab("log Concentrations (ng/L)")+mytheme+theme(legend.position = c(0.73,0.85))+scale_x_continuous(breaks = c(-4,-2,0,2,4,6,8,10))

dev.off()

Data_Sample_S<-filter(Data_Sample,Data_Sample$Environmental_media==c(5,6,7,8))
Data_Sample_S<-melt(Data_Sample_S)
Data_Sample_S<-filter(Data_Sample_S,Data_Sample_S$variable=="Concentration")
Data_antibiotic_PNEC_S<-melt(PNEC2)
Data_antibiotic_PNEC_S<-filter(Data_antibiotic_PNEC_S,Data_antibiotic_PNEC_S$variable=="PNEC_S")
Data_antibiotic_PNEC_S2<-Data_antibiotic_PNEC_S
Data_antibiotic_PNEC_S2[,2]<-Data_antibiotic_PNEC_S[,2]/median(Data_antibiotic_PNEC_S$value)*median(Data_Sample_S$value)
Data_antibiotic_and_PNEC_S<-bind_rows(Data_Sample_S,Data_antibiotic_PNEC_S)
Data_antibiotic_and_PNEC_S2<-bind_rows(Data_Sample_S,Data_antibiotic_PNEC_S2)
Data_antibiotic_and_PNEC_S$variable = gsub( "Concentration","Environmental Concentration", Data_antibiotic_and_PNEC_S$variable )
Data_antibiotic_and_PNEC_S2$variable = gsub( "Concentration","Environmental Concentration", Data_antibiotic_and_PNEC_S2$variable )
Data_antibiotic_and_PNEC_S$variable = gsub( "PNEC_S","PNEC", Data_antibiotic_and_PNEC_S$variable )
Data_antibiotic_and_PNEC_S2$variable = gsub( "PNEC_S","PNECf", Data_antibiotic_and_PNEC_S2$variable )
colnames(Data_antibiotic_and_PNEC_S)<-c("Solid Phase","value")
colnames(Data_antibiotic_and_PNEC_S2)<-c("Solid Phase","value")

cairo_pdf("Data_antibiotic_and_PNEC_S.pdf",width =5,height=4,family="Times")
par(mar = c(10, 5, 5, 5) + .2) 
ggplot(Data_antibiotic_and_PNEC_S,aes(x=log10(value),fill=`Solid Phase`))+geom_density(adjust=5,alpha=.3)+
  scale_fill_manual(values=brewer.pal(3,"Set2")[c(1:3)])+geom_vline(xintercept=log10(median(Data_antibiotic_PNEC_S$value)),size=.5,linetype="dashed",colour="#FC8D62")+
  geom_vline(xintercept=log10(median(Data_Sample_S$value)),size=.5,linetype="dashed",colour="#66C2A5")+
  ylab("Density")+xlab("log Concentrations (μg/kg)")+mytheme+theme(legend.position = c(0.23,0.85))+
  scale_x_continuous(breaks = c(-4,-2,0,2,4,6,8,10))

dev.off()
cairo_pdf("Data_antibiotic_and_PNEC_S2.pdf",width =5,height=4,family="Times")
ggplot(Data_antibiotic_and_PNEC_S2,aes(x=log10(value),fill=`Solid Phase`))+geom_density(adjust=5,alpha=.3)+
  scale_fill_manual(values=brewer.pal(3,"Set2")[c(1:3)])+
  geom_vline(xintercept=log10(median(Data_Sample_S$value)),size=.5,linetype="dashed",colour="#8DA0CB")+
  ylab("Density")+xlab("log Concentrations (μg/kg)")+mytheme+theme(legend.position = c(0.23,0.85))+
  scale_x_continuous(breaks = c(-4,-2,0,2,4,6,8,10))

dev.off()

 
## Boxplot of Pv score, O score, PBT score, and PvOPBT score for the various antibiotic classifications.
 
cols <- c("1Macrolides"="#E41A1C",
          "2Quinolones"="#377EB8",
          "3Tetracyclines"="#4DAF4A",
          "4Sulfonamides"=	"#984EA3",
          "5Others"=	"#FF7F00",
          "6Unclassified"=	"#A65628",
          "7Aminoglycosides"	="#F781BF",
          "8β–Lactam"=	"#999999")
PvOPBT_Order_Score$Classifications = gsub("Macrolides" , "1Macrolides", PvOPBT_Order_Score$Classifications )
PvOPBT_Order_Score$Classifications = gsub("Quinolones" , "2Quinolones", PvOPBT_Order_Score$Classifications )
PvOPBT_Order_Score$Classifications = gsub("Tetracyclines" , "3Tetracyclines", PvOPBT_Order_Score$Classifications )
PvOPBT_Order_Score$Classifications = gsub("Sulfonamides" , "4Sulfonamides", PvOPBT_Order_Score$Classifications )
PvOPBT_Order_Score$Classifications = gsub("Others" , "5Others", PvOPBT_Order_Score$Classifications )
PvOPBT_Order_Score$Classifications = gsub("Unclassified" , "6Unclassified", PvOPBT_Order_Score$Classifications )
PvOPBT_Order_Score$Classifications = gsub("Aminoglycosides" , "7Aminoglycosides", PvOPBT_Order_Score$Classifications )
PvOPBT_Order_Score$Classifications = gsub("β–Lactam" , "8β–Lactam", PvOPBT_Order_Score$Classifications )
cairo_pdf("PV_BOX.pdf",width =5,height=4,family="Times")
ggplot(PvOPBT_Order_Score,aes(y=`Pv Score`,x=Classifications,fill=Classifications))+  
  stat_compare_means(method = "kruskal.test", label.x=1.5,label.y = 1.1)+         
  stat_compare_means(label = "p.signif", method = "wilcox.test",
                     ref.group = ".all.", hide.ns = TRUE,label.y = 1,method.args = list(alternative = "two.sided") )+
  geom_boxplot()+ 
  scale_fill_manual(values=cols)+mytheme+
  scale_x_discrete( labels=c("Macrolides",
                             "Quinolones",
                             "Tetracyclines",
                             "Sulfonamides",
                             "Others",
                             "Unclassified",
                             "Aminoglycosides",
                             "β–Lactam"))+
  stat_summary(fun.y = "mean",geom = "point",shape=23,size=3,fill="white")+
  theme(axis.text.x  = 
          element_text(angle = 60,hjust = 1.1,vjust = 1.1))+
  xlab("Classifications of Antibiotics")+ylab("Pv Score")

dev.off()
cairo_pdf("O_BOX.pdf",width =5,height=4,family="Times")
ggplot(PvOPBT_Order_Score,aes(y=`O Score`,x=Classifications,fill=Classifications))+  
  stat_compare_means(method = "kruskal.test", label.x=1.5,label.y = 1.1)+         
  stat_compare_means(label = "p.signif", method = "wilcox.test",
                     ref.group = ".all.", hide.ns = TRUE,label.y = 1,method.args = list(alternative = "two.sided") )+
  geom_boxplot()+ 
  scale_fill_manual(values=cols)+mytheme+
  scale_x_discrete( labels=c("Macrolides",
                             "Quinolones",
                             "Tetracyclines",
                             "Sulfonamides",
                             "Others",
                             "Unclassified",
                             "Aminoglycosides",
                             "β–Lactam"))+
  stat_summary(fun.y = "mean",geom = "point",shape=23,size=3,fill="white")+
  theme(axis.text.x  = 
          element_text(angle = 60,hjust = 1.1,vjust = 1.1))+
  xlab("Classifications of Antibiotics")+ylab("O Score")

dev.off()

cairo_pdf("PBT_BOX.pdf",width =5,height=4,family="Times")
ggplot(PvOPBT_Order_Score,aes(y=`PBT Score`,x=Classifications,fill=Classifications))+  
  stat_compare_means(method = "kruskal.test", label.x=1.5,label.y = 1.1)+         
  stat_compare_means(label = "p.signif", method = "wilcox.test",
                     ref.group = ".all.", hide.ns = TRUE,label.y =1,method.args = list(alternative = "two.sided") )+
  geom_boxplot()+ 
  scale_fill_manual(values=cols)+mytheme+
  scale_x_discrete( labels=c("Macrolides",
                             "Quinolones",
                             "Tetracyclines",
                             "Sulfonamides",
                             "Others",
                             "Unclassified",
                             "Aminoglycosides",
                             "β–Lactam"))+
  stat_summary(fun.y = "mean",geom = "point",shape=23,size=3,fill="white")+
  theme(axis.text.x  = 
          element_text(angle = 60,hjust = 1.1,vjust = 1.1))+
  xlab("Classifications of Antibiotics")+ylab("PBT Score")

dev.off()


cairo_pdf("PVOPBT_BOX.pdf",width =5,height=4,family="Times")
ggplot(PvOPBT_Order_Score,aes(y=`PvOPBT Score`,x=Classifications,fill=Classifications))+  
  stat_compare_means(method = "kruskal.test", label.x=1.5,label.y = 1.1)+         
  stat_compare_means(label = "p.signif", method = "wilcox.test",
                     ref.group = ".all.", hide.ns = TRUE,label.y = 1,method.args = list(alternative = "two.sided") )+
  geom_boxplot()+ 
  scale_fill_manual(values=cols)+mytheme+
  scale_x_discrete( labels=c("Macrolides",
                             "Quinolones",
                             "Tetracyclines",
                             "Sulfonamides",
                             "Others",
                             "Unclassified",
                             "Aminoglycosides",
                             "β–Lactam"))+
  stat_summary(fun.y = "mean",geom = "point",shape=23,size=3,fill="white")+
  theme(axis.text.x  = 
          element_text(angle = 60,hjust = 1.1,vjust = 1.1))+
  xlab("Classifications of Antibiotics")+ylab("PvOPBT Score")

dev.off()
PvOPBT_Order_Score_melt<-melt(PvOPBT_Order_Score)
PvOPBT_Order_Score_melt<-PvOPBT_Order_Score_melt[1:420,c(1,3,4)]

cairo_pdf("Score_BOX2.pdf",width =10,height=8,family="Times")
ggplot(PvOPBT_Order_Score_melt,aes(y=value,x=Classifications,fill=Classifications))+  
  stat_compare_means(method = "kruskal.test", label.x=1.5,label.y = 1.1)+         
  stat_compare_means(label = "p.signif", method = "wilcox.test",
                     ref.group = ".all.", hide.ns = TRUE,label.y = 1,method.args = list(alternative = "two.sided") )+
  geom_boxplot()+ 
  scale_fill_manual(values=cols)+mytheme+
  scale_x_discrete( labels=c("Macrolides",
                             "Quinolones",
                             "Tetracyclines",
                             "Sulfonamides",
                             "Others",
                             "Unclassified",
                             "Aminoglycosides",
                             "β–Lactam"))+
  stat_summary(fun.y = "mean",geom = "point",shape=23,size=3,fill="white")+
  theme(axis.text.x  = 
          element_text(angle = 60,hjust = 1.1,vjust = 1.1)
          )+
  xlab("Classifications of Antibiotics")+ylab("Score")+
  facet_wrap(~PvOPBT_Order_Score_melt$variable,nrow = 2)
dev.off()

source("PvOPBT Method for Phases.R")
source("PvOPBT Method for Pathways.R")
PvOPBT_A_Order1<-PvOPBT_A_Order[order(PvOPBT_A_Order$Antibiotics),]
PvOPBT_S_Order1<-PvOPBT_S_Order[order(PvOPBT_S_Order$Antibiotics),]
PvOPBT_A_S<-bind_cols(PvOPBT_A_Order1,PvOPBT_S_Order1[,7])

PvOPBT_A_S<-mutate(PvOPBT_A_S,Deviation=((-PvOPBT_A_S$Rankings...7+PvOPBT_A_S$Rankings...8)/105*100 ))
PvOPBT_A_S<-add_column(PvOPBT_A_S, Comparision="Path")
PvOPBT_A_S<-add_column(PvOPBT_A_S, lable=PvOPBT_A_S$Antibiotics)
a<-.1
for (b in 1:105) {
if (PvOPBT_A_S[b,9] > 100*a)
    PvOPBT_A_S[b,10]<-"Aqueous Phase > Solid Phase"
    
  
  else
  {
    if (PvOPBT_A_S[b,9] < -100*a)
    PvOPBT_A_S[b,10]<-"Aqueous Phase < Solid Phase"
  else
    {PvOPBT_A_S[b,10]<-"Aqueous Phase ≈ Solid Phase"
    PvOPBT_A_S[b,11]<-NA}
  }
}
x<-c(0,0,26,26)
y<-c(0,-0.5,-0.5,0)
area1 <- as.data.frame(cbind(x, y))
x<-c(26,26,53,53)
y<-c(0,-0.5,-0.5,0)
area2 <- as.data.frame(cbind(x, y))
x<-c(53,53,79,79)
y<-c(0,-0.5,-0.5,0)
area3 <- as.data.frame(cbind(x, y))
x<-c(79,79,105,105)
y<-c(0,-0.5,-0.5,0)
area4 <- as.data.frame(cbind(x, y))

y<-c(0,0,26,26)
x<-c(0,-0.5,-0.5,0)
area5 <- as.data.frame(cbind(x, y))
y<-c(26,26,53,53)
x<-c(0,-0.5,-0.5,0)
area6 <- as.data.frame(cbind(x, y))
y<-c(53,53,79,79)
x<-c(0,-0.5,-0.5,0)
area7 <- as.data.frame(cbind(x, y))
y<-c(79,79,105,105)
x<-c(0,-0.5,-0.5,0)
area8 <- as.data.frame(cbind(x, y))

x<-c(0,105-105*a,0)
y<-c(105*a,105,105)
area9 <- as.data.frame(cbind(x, y))
x<-c(0,0,105-105*a,105,105,105*a)
y<-c(0,105*a,105,105,105-105*a,0)
area10<- as.data.frame(cbind(x, y))
x<-c(105*a,105,105)
y<-c(0,0,105-105*a)
area11 <- as.data.frame(cbind(x, y))
cols <- c("Macrolides"="#E41A1C",
          "Quinolones"="#377EB8",
          "Tetracyclines"="#4DAF4A",
          "Sulfonamides"=	"#984EA3",
          "Others"=	"#FF7F00",
          "Unclassified"=	"#A65628",
          "Aminoglycosides"	="#F781BF",
          "β–Lactam"=	"#999999")
cairo_pdf("PvOPBT_A_S.pdf",width =6,height=4,family="Times")
par(mar = c(10, 5, 5, 5) + .2) 
ggplot(PvOPBT_A_S, aes(x=Rankings...7,y=Rankings...8,fill=Classifications)) +
  geom_polygon(data = area1,aes(x = x,y = y),fill = "#A50026",alpha = 1)+
  geom_polygon(data = area2,aes(x = x,y = y),fill = "#FDAE61",alpha = 1)+
  geom_polygon(data = area3,aes(x = x,y = y),fill = "#A6D96A",alpha = 1)+
  geom_polygon(data = area4,aes(x = x,y = y),fill = "#006837",alpha = 1)+
  geom_polygon(data = area5,aes(x = x,y = y),fill = "#A50026",alpha = 1)+
  geom_polygon(data = area6,aes(x = x,y = y),fill = "#FDAE61",alpha = 1)+
  geom_polygon(data = area7,aes(x = x,y = y),fill = "#A6D96A",alpha = 1)+
  geom_polygon(data = area8,aes(x = x,y = y),fill = "#006837",alpha = 1)+
  geom_polygon(data = area9,aes(x = x,y = y),fill = "#FC8D62",alpha = 0.1)+
  geom_polygon(data = area10,aes(x = x,y = y),fill = "#8DA0CB",alpha = 0.1)+
  geom_polygon(data = area11,aes(x = x,y = y),fill = "#66C2A5",alpha = 0.1)+
  geom_abline(intercept=0,slope=1 ,colour="grey",size=0.5,linetype="dashed")+
  geom_abline(intercept=105*a,slope=1 ,size=0.5,linetype="dashed",alpha=0.7)+
  geom_abline(intercept=-105*a,slope=1 ,size=0.5,linetype="dashed",alpha=0.7)+
  geom_point(colour="black",shape=21,stroke=0.7,size=3,alpha=1,show.legend=T)+
  theme_light()+theme(legend.position = "right")+labs(fill="PvOPBT Raking")+
  geom_text(aes(label=lable,color=Classifications),size=2,hjust=-.2,show.legend = FALSE)+
  scale_color_manual(values=cols)+
  scale_fill_manual(values=cols,limits=c("Macrolides",   "Quinolones",
                                         "Tetracyclines",
                                         "Sulfonamides",
                                         "Others",
                                         "Unclassified",
                                         "Aminoglycosides",
                                         "β–Lactam"))+
  xlab("PvOPBT Ranking in Aqueous Phase")+ylab("PvOPBT Ranking in Solid Phase")+
  scale_x_discrete( limits =c(0,26,53,79,105))+scale_y_discrete(limits=c(0,26,53,79,105))+
  labs(fill="Classifications")

dev.off()
# PvOPBT_A_S2<-PvOPBT_A_S[,c(1,7,8)]
# PvOPBT_A_S2<-filter(PvOPBT_A_S2,PvOPBT_A_S2$Rankings...7<54,PvOPBT_A_S2$Rankings...8<54)
# PvOPBT_A_S2<-melt(PvOPBT_A_S2,id.vars = "Classifications")
# ggplot(PvOPBT_A_S2, aes(x = Classifications, y = value))+
#   stat_compare_means(label = "p.signif", method = "wilcox.test",
#                      ref.group = ".Rankings...7.", hide.ns = TRUE,label.y =1,method.args = list(alternative = "two.sided") )+
#   geom_boxplot(outlier.size = 1, aes(fill=factor(variable)),
#                position = position_dodge(0.8),size=0.5) +  
#   guides(fill=guide_legend(title="treatment"))+
#   theme_minimal()+
#   theme(axis.title=element_text(size=13,face="plain",color="black"),
#         axis.text = element_text(size=11,face="plain",color="black"),
#         panel.background=element_rect(colour="black",fill=NA),
#         panel.grid.minor=element_blank(),
#         legend.position="right",
#         legend.background=element_rect(colour=NA,fill=NA),
#         axis.ticks=element_line(colour="black"))


PvOPBT_Order2_Path1<-PvOPBT_Order_Path1[order(PvOPBT_Order_Path1$Antibiotics),]
PvOPBT_Order2_Path2<-PvOPBT_Order_Path2[order(PvOPBT_Order_Path2$Antibiotics),]
PvOPBT_Path1_Path2<-bind_cols(PvOPBT_Order2_Path1,PvOPBT_Order2_Path2[,7])

PvOPBT_Path1_Path2<-mutate(PvOPBT_Path1_Path2,Deviation=((-PvOPBT_Path1_Path2$Rankings...7+PvOPBT_Path1_Path2$Rankings...8)/105*100 ))
PvOPBT_Path1_Path2<-add_column(PvOPBT_Path1_Path2, Comparision="Path")
PvOPBT_Path1_Path2<-add_column(PvOPBT_Path1_Path2, lable=PvOPBT_Path1_Path2$Antibiotics)
for (b in 1:105) {
  if (PvOPBT_Path1_Path2[b,9] > 100*a)
    PvOPBT_Path1_Path2[b,10]<-"Pathway I > Pathway II"
  
  
  else
  {
    if (PvOPBT_Path1_Path2[b,9] < -100*a)
      PvOPBT_Path1_Path2[b,10]<-"Pathway I < Pathway II"
    else
    {PvOPBT_Path1_Path2[b,10]<-"Pathway I ≈ Pathway II"
    PvOPBT_Path1_Path2[b,11]<-NA}
  }
}

cairo_pdf("PvOPBT_Path1_Path2.pdf",width =6,height=4,family="Times")
par(mar = c(10, 5, 5, 5) + .2) 
ggplot(PvOPBT_Path1_Path2, aes(x=Rankings...7,y=Rankings...8,fill=Classifications)) +
  geom_polygon(data = area1,aes(x = x,y = y),fill = "#A50026",alpha = 1)+
  geom_polygon(data = area2,aes(x = x,y = y),fill = "#FDAE61",alpha = 1)+
  geom_polygon(data = area3,aes(x = x,y = y),fill = "#A6D96A",alpha = 1)+
  geom_polygon(data = area4,aes(x = x,y = y),fill = "#006837",alpha = 1)+
  geom_polygon(data = area5,aes(x = x,y = y),fill = "#A50026",alpha = 1)+
  geom_polygon(data = area6,aes(x = x,y = y),fill = "#FDAE61",alpha = 1)+
  geom_polygon(data = area7,aes(x = x,y = y),fill = "#A6D96A",alpha = 1)+
  geom_polygon(data = area8,aes(x = x,y = y),fill = "#006837",alpha = 1)+
  geom_polygon(data = area9,aes(x = x,y = y),fill = "#FC8D62",alpha = 0.1)+
  geom_polygon(data = area10,aes(x = x,y = y),fill = "#8DA0CB",alpha = 0.1)+
  geom_polygon(data = area11,aes(x = x,y = y),fill = "#66C2A5",alpha = 0.1)+
  geom_abline(intercept=0,slope=1 ,colour="grey",size=0.5,linetype="dashed")+
  geom_abline(intercept=105*a,slope=1 ,size=0.5,linetype="dashed",alpha=0.7)+
  geom_abline(intercept=-105*a,slope=1 ,size=0.5,linetype="dashed",alpha=0.7)+
  geom_point(colour="black",shape=21,stroke=0.7,size=3,alpha=1,show.legend=T)+
  theme_light()+theme(legend.position = "right")+labs(fill="PvOPBT Raking")+
  geom_text(aes(label=lable,color=Classifications),size=2,hjust=-.2,show.legend = FALSE)+
  scale_color_manual(values=cols)+
  scale_fill_manual(values=cols,limits=c("Macrolides",   "Quinolones",
                                         "Tetracyclines",
                                         "Sulfonamides",
                                         "Others",
                                         "Unclassified",
                                         "Aminoglycosides",
                                         "β–Lactam"))+
  xlab("PvOPBT Ranking in Pathway I")+ylab("PvOPBT Ranking in Pathway II")+
  scale_x_discrete( limits =c(0,26,53,79,105))+scale_y_discrete(limits=c(0,26,53,79,105))+
  labs(fill="Classifications")
dev.off()


PvOPBT_Path<-PvOPBT_Path1_Path2[,c(1,2,9,10)]
PvOPBT_Path<-filter(PvOPBT_Path,abs(PvOPBT_Path$Deviation)>a*100)
PvOPBT_Path<-add_column(PvOPBT_Path,col="col")
for (b in 1:nrow(PvOPBT_Path)) {
  if (PvOPBT_Path[b,3] > 0)
    PvOPBT_Path[b,5]<-"#FC8D62"
  else
    PvOPBT_Path[b,5]<-"#66C2A5"
}

PvOPBT_Path[,3]<-abs(PvOPBT_Path[,3])

cairo_pdf("PvOPBT_Path.pdf",width =10,height=5,family="Times")
ggplot(PvOPBT_Path, aes(y=reorder(Antibiotics,Deviation),x=Deviation,fill=Classifications))+
  geom_segment(aes(yend = Antibiotics),xend=0,colour=PvOPBT_Path$col)+
  geom_point(shape=21,size=4,colour="black",alpha=1)+
  #geom_bar(stat = "identity" ,color="black", width=0.7,size=0.25,alpha=1)+
  mytheme+
  #theme(axis.text.y = element_text(angle = 90,hjust = 1,vjust = 1))+
  scale_fill_manual(values=cols,limits=c("Macrolides",   "Quinolones",
                                         "Tetracyclines",
                                         "Sulfonamides",
                                         "Others",
                                         "Unclassified",
                                         "Aminoglycosides",
                                         "β–Lactam"))+
  facet_wrap(~Comparision,scales = "free_y",nrow =1)+
  labs(fill="Classifications")+
  #geom_hline(yintercept=c(14.84924,-14.84924),size=0.5,linetype="dashed",alpha=0.7)+
  xlab("Deviation Percentage (%)")+ylab("Antibiotics")+theme(
    strip.text = element_text(size = rel(1.1),colour = "black"),
    axis.title=element_text(size=14,colour = "black"),
    axis.text = element_text(size=11,colour = "black"),
    legend.title=element_text(size=13,colour = "black"),
    legend.background = element_blank(),
    legend.position = "right") 
dev.off()

PvOPBT_Path<-PvOPBT_A_S[,c(1,2,9,10)]
PvOPBT_Path<-filter(PvOPBT_Path,abs(PvOPBT_Path$Deviation)>a*100)
PvOPBT_Path<-add_column(PvOPBT_Path,col="col")
for (b in 1:nrow(PvOPBT_Path)) {
  if (PvOPBT_Path[b,3] > 0)
    PvOPBT_Path[b,5]<-"#FC8D62"
  else
    PvOPBT_Path[b,5]<-"#66C2A5"
}

PvOPBT_Path[,3]<-abs(PvOPBT_Path[,3])

cairo_pdf("PvOPBT_Phase.pdf",width =10,height=6,family="Times")
ggplot(PvOPBT_Path, aes(y=reorder(Antibiotics,Deviation),x=Deviation,fill=Classifications))+
  geom_segment(aes(yend = Antibiotics),xend=0,colour=PvOPBT_Path$col)+
  geom_point(shape=21,size=4,colour="black",alpha=1)+
  #geom_bar(stat = "identity" ,color="black", width=0.7,size=0.25,alpha=1)+
  mytheme+
  #theme(axis.text.y = element_text(angle = 90,hjust = 1,vjust = 1))+
  scale_fill_manual(values=cols,limits=c("Macrolides",   "Quinolones",
                                         "Tetracyclines",
                                         "Sulfonamides",
                                         "Others",
                                         "Unclassified",
                                         "Aminoglycosides",
                                         "β–Lactam"))+
  facet_wrap(~Comparision,scales = "free_y",nrow =1)+
  labs(fill="Classifications")+
  #geom_hline(yintercept=c(14.84924,-14.84924),size=0.5,linetype="dashed",alpha=0.7)+
  xlab("Deviation Percentage (%)")+ylab("Antibiotics")+theme(
    strip.text = element_text(size = rel(1.1),colour = "black"),
    axis.title=element_text(size=14,colour = "black"),
    axis.text = element_text(size=11,colour = "black"),
    legend.title=element_text(size=13,colour = "black"),
    legend.background = element_blank(),
    legend.position = "right") 
dev.off()

PvOPBT_A_S<-PvOPBT_A_S[order(PvOPBT_A_S$Antibiotics),]
kow<-PBT1[order(PBT1$PREFERRED_NAME),]
PvOPBT_A_S<-bind_cols(PvOPBT_A_S,kow[,9])

ggplot(PvOPBT_A_S, aes(y=Deviation,x=Log_Kow_EPI_EST,fill=Classifications))+
  geom_point(size=3,shape=21)+
  scale_fill_manual(values=cols,limits=c("Macrolides",   "Quinolones",
                                         "Tetracyclines",
                                         "Sulfonamides",
                                         "Aminoglycosides",
                                         "β–Lactam"))+
  stat_smooth(method = lm)
PvOPBT_A_S<-filter(PvOPBT_A_S,PvOPBT_A_S$Rankings...7< 54)
PvOPBT_A_S<-filter(PvOPBT_A_S,PvOPBT_A_S$Rankings...8 < 54)
ggplot(PvOPBT_A_S, aes(x=Classifications,y=Deviation,fill=Classifications))+
  geom_boxplot()+
  scale_fill_manual(values=cols,limits=c("Macrolides",   "Quinolones",
                                         "Tetracyclines",
                                         "Sulfonamides",
                                         "Aminoglycosides",
                                         "β–Lactam"))

Compared_with_Previous_study <- read_excel("/Users/huangfuyang/重要文件/文章/中国抗生素风险/优先控制抗生素手稿/Compared with Previous study.xlsx", 
                                         sheet = "Sheet1")
Compared_with_Previous_study1<-Compared_with_Previous_study[,c(1:15)]
mydata<-melt(Compared_with_Previous_study1,id.vars = "PvOPBT ranking")
mydata[mydata==0] <- NA
cairo_pdf("Compared_with_Previous_study.pdf",width =8,height=5,family="Times")
ggplot(mydata, aes(y=variable,x=`PvOPBT ranking`,size=value))+
  geom_point(shape=21,fill="#FF7F00")+mytheme+scale_x_discrete(limit=Compared_with_Previous_study$`PvOPBT ranking`)+
  scale_y_discrete(limit=c("(Zhou et al. 2019)", "(Mansour et al. 2016)", "(Guo et al. 2016)","(Al-Khazrajy and Boxall 2016)",
                           "(Menz et al. 2015)","(Daouk et al. 2015)", "(Ortiz de Garcia et al. 2013)","(Kumar and Xagoraraki 2010)",
                           "(Kim et al. 2008)",
                           "(Li et al. 2020)",
                           "(Li et al. 2019)",
                           "(Wang et al. 2014)",
                           "(Sui et al. 2012)",
                           "This study"
                           ))+
  theme(axis.text.x  =element_text(angle = 60,hjust = 1.1,vjust = 1.1))+ylab("Studies")+xlab("Prioritization of Antibiotics")
dev.off()
mydata<-PvOPBT_Order_Score[,5:8]
mydata<-melt(mydata)
# ggplot(mydata,aes(x=value,fill=variable))+geom_density(adjust=1.5,alpha=.5)+
#   scale_fill_manual(values=brewer.pal(4,"Set3")[c(1:4)])+
#   mytheme+theme(legend.position = c(0.23,0.85))
Ranking_usage <- read_excel("~/Desktop/工作簿2.xlsx", sheet = "Sheet3")
cols <- c("Macrolides"="#E41A1C",
          "Quinolones"="#377EB8",
          "Tetracyclines"="#4DAF4A",
          "Sulfonamides"=	"#984EA3",
          "Others"=	"#FF7F00")


cairo_pdf("Ranking_usage.pdf",width =7,height=5,family="Times")
ggplot(Ranking_usage, aes(x=AS2,y=Percentage))+
  geom_point(aes(size=`Usage(Tons)`,fill=Classifications),colour="black",alpha=1,shape=21,)+
  geom_text(aes(label= Antibiotics,color=Classifications),size=3,hjust=-.2,show.legend = FALSE)+
  scale_fill_manual(values=cols)+
  scale_color_manual(values=cols)+
  scale_size_continuous( range = c(3,7.5) ) +
  mytheme+theme(legend.position = "right")+
  xlab("Mean of PvOPBT scores in aqueous and solid phases")+
  ylab("Percentage of top-priority antibiotics for veterinary use(%)") +
  geom_text(aes(x = 0.6, y = 2, label = as.character(as.expression(eq))), parse = TRUE)
  
dev.off()  



